<?php
function getYouTubeTranscript($videoId) {
    $pythonScriptPath = __DIR__ . "/youtube.py";
    $command = escapeshellcmd("/usr/bin/python3 " . $pythonScriptPath . " " . $videoId) . " 2>&1";
    $output = shell_exec($command);

    if ($output === null) {
        return 'Command failed to execute.';
    } elseif ($output === '') {
        return 'Command executed but no output returned.';
    }
    return $output;
}

$transcript = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['videoId'])) {
        $videoId = $_POST['videoId'];
        $transcript = getYouTubeTranscript($videoId);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>YouTube Transcript Fetcher</title>
</head>
<body>
    <div>
        <h2>Enter YouTube Video ID</h2>
        <form action="youtube.php" method="post">
            <input type="text" name="videoId" required>
            <input type="submit" value="Get Transcript">
        </form>
        <?php if ($transcript): ?>
            <h3>Transcript:</h3>
            <p><?php echo nl2br(htmlspecialchars($transcript)); ?></p>
        <?php endif; ?>
    </div>
</body>
</html>

