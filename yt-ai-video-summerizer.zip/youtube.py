import sys
import re
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api._errors import TranscriptsDisabled

def get_transcript(video_id):
    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
        for entry in transcript:
            cleaned_text = re.sub(r'\s+', ' ', entry['text'])
            print(cleaned_text)
    except TranscriptsDisabled:
        print(f"Transcript is disabled for video with ID {video_id}.")
    except Exception as e:
        print(f"An error occurred: {e}")

if len(sys.argv) > 1:
    video_id = sys.argv[1]
    get_transcript(video_id)

