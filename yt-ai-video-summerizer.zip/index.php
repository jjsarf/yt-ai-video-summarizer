<!DOCTYPE html>
<html>
<head>
    <title>YouTube Transcript Fetcher</title>
</head>
<body>
    <div>
        <h2>Enter YouTube Video ID</h2>
        <form action="youtube.php" method="post">
            <input type="text" name="videoId" required>
            <input type="submit" value="Get Transcript">
        </form>
    </div>
</body>
</html>

