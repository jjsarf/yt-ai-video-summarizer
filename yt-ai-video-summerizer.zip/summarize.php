<?php
// Set the headers to allow cross-origin requests and return JSON
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Define the API key
define('API_KEY', 'your-openai-key-here'); // Replace with your actual GPT-4 API key

// Retrieve POST data or use default text
$input = isset($_POST['text']) ? $_POST['text'] : 'Default text for summarization.';
$max_tokens = isset($_POST['max_tokens']) ? (int)$_POST['max_tokens'] : 100;

// Prepare the messages for the API request
$messages = array(
    array(
        "role" => "system",
        "content" => "You will be provided with video transcript, and your task is to summarize the transcripts as follows:\n\n-Overall summary of video\n-Key Points (what one needs to do if applicable and how). Try to put some concise bullet points with a brief intro paragraph."
    ),
    array(
        "role" => "user",
        "content" => $input
    )
);

// Prepare the request data to be sent to the GPT API
$data = array(
    'model' => 'gpt-4o',
    'messages' => $messages,
    'temperature' => 0,
    'max_tokens' => $max_tokens,
    'top_p' => 1,
    'frequency_penalty' => 0,
    'presence_penalty' => 0
);

// Set the curl options for the API request
$options = array(
    CURLOPT_URL => 'https://api.openai.com/v1/chat/completions',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($data),
    CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json',
        'Authorization: Bearer ' . API_KEY
    )
);

// Initialize the curl request
$ch = curl_init();
curl_setopt_array($ch, $options);

// Execute the curl request and capture the response
$response = curl_exec($ch);
if ($response === false) {
    echo json_encode(array('error' => curl_error($ch)));
    curl_close($ch);
    exit;
}

$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

// Close the curl session
curl_close($ch);

// Check for a successful response
if ($http_status === 200) {
    echo $response;
} else {
    echo json_encode(array('error' => 'Failed to retrieve data from the API. HTTP Status: ' . $http_status));
}
?>

